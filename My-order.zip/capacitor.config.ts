import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.my.order',
  appName: 'My order',
  webDir: 'dist'
};

export default config;
