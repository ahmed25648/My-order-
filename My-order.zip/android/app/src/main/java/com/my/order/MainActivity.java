package com.my.order;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
